package ejercicio3.servicios;

import ejercicio3.entidades.Baraja;

public class Creador {
    public static Baraja crearBaraja() {
        return new Baraja();
    }
}
