
package Entidad;


public class Ejemplo1 {

    
    public static void main(String[] args) {
       
        Persona p1=new Persona("Pablo","Gimenez",new DNI("A",35478521));
        
        System.out.println(p1.toString());
        
    }
    
}
